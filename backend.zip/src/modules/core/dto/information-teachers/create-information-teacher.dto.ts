import { InformationTeacherDto } from '@core/dto';

export class CreateInformationTeacherDto extends InformationTeacherDto {}
