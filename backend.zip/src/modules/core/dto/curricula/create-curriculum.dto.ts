import { CurriculumDto } from '@core/dto';

export class CreateCurriculumDto extends CurriculumDto {}
