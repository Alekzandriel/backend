export * from './career.entity';
export * from './catalogue.entity';
export * from './curriculum.entity';
export * from './information-student.entity';
export * from './information-teacher.entity';
export * from './institution.entity';
export * from './student.entity';
export * from './subject.entity';
