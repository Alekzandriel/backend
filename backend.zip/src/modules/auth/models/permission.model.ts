export interface PermissionModel {
  possession: string;
  action: string;
  resource: string;
}
