export interface PayloadTokenModel {
  id: string;
  role: string;
}
