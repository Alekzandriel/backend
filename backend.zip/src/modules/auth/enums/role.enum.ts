export enum RoleEnum {
  ADMIN = 'admin',
  GUEST = 'guest',
  TEACHER = 'teacher',
  COORDINATOR_CAREER = 'coordinator_career',
  COORDINATOR_ADMINISTRATIVE = 'coordinator_administrative',
  STUDENT = 'student',
  RECTOR = 'rector',
}
