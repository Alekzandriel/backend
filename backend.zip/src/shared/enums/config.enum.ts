export enum ConfigEnum {
  CONFIG = 'config',
}
