export interface ServiceResponseHttpModel {
  data: object;
  pagination?: any;
}
